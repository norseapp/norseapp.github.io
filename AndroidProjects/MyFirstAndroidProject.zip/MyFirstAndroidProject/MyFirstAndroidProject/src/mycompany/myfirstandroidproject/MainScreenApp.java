package mycompany.myfirstandroidproject;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;
import android.widget.Button;
import android.content.Intent;


public class MainScreenApp extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_first);
        //Button from the activity
        Button viewTodoList=(Button) findViewById(R.id.viewTodoList);
        viewTodoList.setOnClickListener(new View.OnClickListener(){
        	 @Override
             public void onClick(View view ){
                    Intent intent=new Intent(getApplicationContext(), AllTodoActivity.class);
                    startActivity(intent);
                 }
        	
        });
        Button AddButton=(Button) findViewById(R.id.AddButton);
        AddButton.setOnClickListener(new View.OnClickListener(){
            @Override
        public void onClick(View view ){
               Intent intent=new Intent(getApplicationContext(), NewTodoActivity.class);
               startActivity(intent);
            }
        });

    };}